# ALX.GPT.Dark — build na nuvem pelo GitHub

Este pacote inclui um workflow GitHub Actions que tenta compilar o protótipo Android e publica o APK como artefato para download.

## Passos pelo celular Android

1. Entre em https://github.com/ ou crie uma conta.
2. Crie um repositório novo, por exemplo `ALX-GPT-Dark`. Para um primeiro teste, pode ser privado.
3. Extraia o ZIP no celular usando o gerenciador de arquivos.
4. Envie **o conteúdo da pasta** para a raiz do repositório, preservando pastas como `app/`, `gradle/` (se existir) e `.github/workflows/android.yml`. Não envie apenas o ZIP como um arquivo isolado.
5. Abra a aba **Actions** do repositório.
6. Se o GitHub pedir, habilite Actions. Abra o workflow **Build Android APK** e toque em **Run workflow**. Um envio para a branch `main` também inicia a compilação.
7. Abra a execução mais recente. Se aparecer um visto verde, role até **Artifacts** e baixe `ALX-GPT-Dark-debug-APK`.
8. Extraia o artefato baixado e toque em `app-debug.apk` para instalar. O Android pode pedir permissão para instalar apps dessa fonte.

## Se falhar
Abra a execução do workflow e consulte a etapa vermelha nos logs. A compilação pode precisar de correções de dependências ou de código; não considere o APK pronto até a execução terminar com sucesso e o aplicativo ser testado no aparelho.

## Limites do protótipo
Este é um protótipo inicial. A captura de tela automática, o reconhecimento de jogos e a análise estatística ainda não estão implementados. Não prevê nem garante ganhos de cassino.
