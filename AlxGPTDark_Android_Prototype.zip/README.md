# Alx.GPT.Dark — Android prototype

A Kotlin/Android Studio starter project for a floating diamond overlay and a casino-results statistics interface.

## Included
- Dark themed Android launcher screen.
- User-granted overlay permission flow.
- Movable floating diamond overlay.
- Prototype menu for roulette, slots, Tigrinho and Dragão.
- Basic disclosure that the app does not guarantee or predict wins.

## Not yet implemented
- APK build and device testing.
- MediaProjection screen-capture flow.
- OCR or image interpretation.
- Game-specific result extraction.
- Statistical models and persistence.

## Build
1. Open this folder in Android Studio (recent stable version).
2. Allow Gradle sync and install the Android SDK platform required by `compileSdk`.
3. Run the `app` configuration on an Android device or emulator.
4. Grant the overlay permission when prompted.

This is source code, not a precompiled APK. Overlay behavior and Android foreground-service requirements should be tested on the target Android version before distribution.

## Important limitations
The app can calculate statistics from visible/recorded results. It cannot reliably identify a secret “payment time” or guarantee the next result of a random casino game. Screen capture must be explicitly approved by the user through Android's system permission flow.
