package com.alxgpt.dark

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color

class MainActivity : Activity() {
    private val bg = Color.rgb(5, 8, 22)
    private val cyan = Color.rgb(34, 211, 238)
    private val white = Color.rgb(241, 245, 249)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    private fun render() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 40, 28, 28)
            setBackgroundColor(bg)
            gravity = Gravity.CENTER_HORIZONTAL
        }

        val logo = TextView(this).apply {
            text = "💎"
            textSize = 54f
            gravity = Gravity.CENTER
        }
        val title = TextView(this).apply {
            text = "Alx.GPT.Dark"
            textSize = 28f
            setTextColor(cyan)
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "Análise estatística para jogos de cassino"
            textSize = 15f
            setTextColor(white)
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 28)
        }
        val info = TextView(this).apply {
            text = "Compatível em projeto com Tigrinho, Dragão, slots e roleta.\\n\\nA análise depende dos dados disponíveis. O app não consegue garantir ganhos nem descobrir horários secretos de pagamento."
            textSize = 15f
            setTextColor(white)
            setPadding(0, 0, 0, 24)
        }
        val overlayButton = Button(this).apply {
            text = "Ativar diamante flutuante"
            setOnClickListener { enableOverlay() }
        }
        val captureButton = Button(this).apply {
            text = "Como funciona a leitura da tela"
            setOnClickListener {
                android.app.AlertDialog.Builder(this@MainActivity)
                    .setTitle("Leitura autorizada")
                    .setMessage("A captura de tela deve ser iniciada por você e aprovada pelo Android. Esta versão inicial prepara o projeto; a análise automática de imagens ainda precisa ser implementada e testada.")
                    .setPositiveButton("Entendi", null)
                    .show()
            }
        }
        val status = TextView(this).apply {
            text = "Versão inicial 0.1.0 • protótipo"
            textSize = 12f
            setTextColor(Color.LTGRAY)
            setPadding(0, 28, 0, 0)
        }

        listOf(logo, title, subtitle, info, overlayButton, captureButton, status).forEach {
            layout.addView(it, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ))
        }
        setContentView(layout)
    }

    private fun enableOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
            return
        }
        if (Build.VERSION.SDK_INT >= 26) {
            startForegroundService(Intent(this, FloatingDiamondService::class.java))
        } else {
            startService(Intent(this, FloatingDiamondService::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        // User returns here after granting overlay permission; tap the button again to start.
    }
}
