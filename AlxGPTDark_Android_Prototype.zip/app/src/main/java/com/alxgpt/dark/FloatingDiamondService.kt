package com.alxgpt.dark

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast

class FloatingDiamondService : Service() {
    private lateinit var windowManager: WindowManager
    private var bubble: TextView? = null
    private var panel: TextView? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (bubble != null) return START_STICKY
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 24
            y = 220
        }

        bubble = TextView(this).apply {
            text = "💎"
            textSize = 30f
            setPadding(18, 12, 18, 12)
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(15, 23, 42))
            setOnClickListener { togglePanel(type) }
            setOnTouchListener(DragTouchListener(params, this@FloatingDiamondService))
        }
        windowManager.addView(bubble, params)
        return START_STICKY
    }

    private fun togglePanel(type: Int) {
        if (panel != null) {
            try { windowManager.removeView(panel) } catch (_: Exception) {}
            panel = null
            return
        }
        val p = WindowManager.LayoutParams(
            280, WindowManager.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 20
            y = 290
        }
        panel = TextView(this).apply {
            text = "Alx.GPT.Dark\\n\\n• Roleta\\n• Tigrinho / Dragão\\n• Slots\\n\\nStatus: aguardando dados\\nAnálise não prevê pagamento garantido."
            textSize = 15f
            setTextColor(Color.WHITE)
            setPadding(24, 22, 24, 22)
            setBackgroundColor(Color.rgb(15, 23, 42))
            setOnClickListener {
                Toast.makeText(this@FloatingDiamondService,
                    "Protótipo: módulo de análise ainda não conectado.",
                    Toast.LENGTH_LONG).show()
            }
        }
        windowManager.addView(panel, p)
    }

    override fun onDestroy() {
        try { bubble?.let { windowManager.removeView(it) } } catch (_: Exception) {}
        try { panel?.let { windowManager.removeView(it) } } catch (_: Exception) {}
        bubble = null
        panel = null
        super.onDestroy()
    }

    private class DragTouchListener(
        private val params: WindowManager.LayoutParams,
        private val service: FloatingDiamondService
    ) : android.view.View.OnTouchListener {
        private var startX = 0
        private var startY = 0
        private var downX = 0f
        private var downY = 0f
        private var moved = false

        override fun onTouch(view: android.view.View, event: MotionEvent): Boolean {
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x
                    startY = params.y
                    downX = event.rawX
                    downY = event.rawY
                    moved = false
                    return false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - downX).toInt()
                    val dy = (event.rawY - downY).toInt()
                    if (kotlin.math.abs(dx) > 8 || kotlin.math.abs(dy) > 8) moved = true
                    if (moved) {
                        params.x = startX - dx
                        params.y = startY + dy
                        try { service.windowManager.updateViewLayout(view, params) } catch (_: Exception) {}
                        return true
                    }
                }
            }
            return false
        }
    }
}
